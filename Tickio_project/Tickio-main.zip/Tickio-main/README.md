# Tickio
Este repositorio contiene el desarrollo de la Aplicacion de reserva de eventos Tickio.
